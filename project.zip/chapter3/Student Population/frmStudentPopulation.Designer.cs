﻿namespace Student_Population
{
    partial class frmStudentPopulation
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtNumberOfStudentsToday = new System.Windows.Forms.TextBox();
            this.txtAnnualGrowthRate = new System.Windows.Forms.TextBox();
            this.txtNumberOfYears = new System.Windows.Forms.TextBox();
            this.txtProjectedNumberOfStudents = new System.Windows.Forms.TextBox();
            this.btnProjectStudentPopulation = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.label1.Location = new System.Drawing.Point(53, 41);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(171, 19);
            this.label1.TabIndex = 0;
            this.label1.Text = "&Number of students today";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.label2.Location = new System.Drawing.Point(53, 74);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(128, 19);
            this.label2.TabIndex = 2;
            this.label2.Text = "&Annual growth rate";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.label3.Location = new System.Drawing.Point(53, 106);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(111, 19);
            this.label3.TabIndex = 4;
            this.label3.Text = "Number of &years";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.label4.Location = new System.Drawing.Point(53, 141);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(191, 19);
            this.label4.TabIndex = 5;
            this.label4.Text = "Projected number of students";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtNumberOfStudentsToday
            // 
            this.txtNumberOfStudentsToday.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.txtNumberOfStudentsToday.Location = new System.Drawing.Point(248, 37);
            this.txtNumberOfStudentsToday.Margin = new System.Windows.Forms.Padding(2);
            this.txtNumberOfStudentsToday.Name = "txtNumberOfStudentsToday";
            this.txtNumberOfStudentsToday.Size = new System.Drawing.Size(151, 25);
            this.txtNumberOfStudentsToday.TabIndex = 1;
            // 
            // txtAnnualGrowthRate
            // 
            this.txtAnnualGrowthRate.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.txtAnnualGrowthRate.Location = new System.Drawing.Point(248, 72);
            this.txtAnnualGrowthRate.Margin = new System.Windows.Forms.Padding(2);
            this.txtAnnualGrowthRate.Name = "txtAnnualGrowthRate";
            this.txtAnnualGrowthRate.Size = new System.Drawing.Size(151, 25);
            this.txtAnnualGrowthRate.TabIndex = 4;
            this.txtAnnualGrowthRate.TextChanged += new System.EventHandler(this.txtAnnualGrowthRate_TextChanged);
            // 
            // txtNumberOfYears
            // 
            this.txtNumberOfYears.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.txtNumberOfYears.Location = new System.Drawing.Point(248, 102);
            this.txtNumberOfYears.Margin = new System.Windows.Forms.Padding(2);
            this.txtNumberOfYears.Name = "txtNumberOfYears";
            this.txtNumberOfYears.Size = new System.Drawing.Size(151, 25);
            this.txtNumberOfYears.TabIndex = 5;
            // 
            // txtProjectedNumberOfStudents
            // 
            this.txtProjectedNumberOfStudents.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.txtProjectedNumberOfStudents.Location = new System.Drawing.Point(248, 136);
            this.txtProjectedNumberOfStudents.Margin = new System.Windows.Forms.Padding(2);
            this.txtProjectedNumberOfStudents.Name = "txtProjectedNumberOfStudents";
            this.txtProjectedNumberOfStudents.ReadOnly = true;
            this.txtProjectedNumberOfStudents.Size = new System.Drawing.Size(151, 25);
            this.txtProjectedNumberOfStudents.TabIndex = 9;
            this.txtProjectedNumberOfStudents.TabStop = false;
            // 
            // btnProjectStudentPopulation
            // 
            this.btnProjectStudentPopulation.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnProjectStudentPopulation.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnProjectStudentPopulation.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnProjectStudentPopulation.FlatAppearance.BorderColor = System.Drawing.Color.LimeGreen;
            this.btnProjectStudentPopulation.FlatAppearance.BorderSize = 0;
            this.btnProjectStudentPopulation.FlatAppearance.MouseOverBackColor = System.Drawing.SystemColors.HotTrack;
            this.btnProjectStudentPopulation.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.btnProjectStudentPopulation.Location = new System.Drawing.Point(57, 215);
            this.btnProjectStudentPopulation.Margin = new System.Windows.Forms.Padding(2);
            this.btnProjectStudentPopulation.Name = "btnProjectStudentPopulation";
            this.btnProjectStudentPopulation.Size = new System.Drawing.Size(130, 75);
            this.btnProjectStudentPopulation.TabIndex = 6;
            this.btnProjectStudentPopulation.Text = "&Project Student Population";
            this.btnProjectStudentPopulation.UseVisualStyleBackColor = false;
            this.btnProjectStudentPopulation.Click += new System.EventHandler(this.btnProjectStudentPopulation_Click);
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnExit.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnExit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnExit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnExit.FlatAppearance.BorderColor = System.Drawing.Color.LimeGreen;
            this.btnExit.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.btnExit.Location = new System.Drawing.Point(269, 215);
            this.btnExit.Margin = new System.Windows.Forms.Padding(2);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(130, 75);
            this.btnExit.TabIndex = 7;
            this.btnExit.Text = "E&xit";
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // frmStudentPopulation
            // 
            this.AcceptButton = this.btnProjectStudentPopulation;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.btnExit;
            this.ClientSize = new System.Drawing.Size(435, 333);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnProjectStudentPopulation);
            this.Controls.Add(this.txtProjectedNumberOfStudents);
            this.Controls.Add(this.txtNumberOfYears);
            this.Controls.Add(this.txtAnnualGrowthRate);
            this.Controls.Add(this.txtNumberOfStudentsToday);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Cursor = System.Windows.Forms.Cursors.Default;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "frmStudentPopulation";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Student Population";
            this.Load += new System.EventHandler(this.frmStudentPopulation_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtNumberOfStudentsToday;
        private System.Windows.Forms.TextBox txtAnnualGrowthRate;
        private System.Windows.Forms.TextBox txtNumberOfYears;
        private System.Windows.Forms.TextBox txtProjectedNumberOfStudents;
        private System.Windows.Forms.Button btnProjectStudentPopulation;
        private System.Windows.Forms.Button btnExit;
    }
}

