﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Telephon_numbers
{
    public partial class frmTelephoneNumbers : Form
    {
        public frmTelephoneNumbers()
        {
            InitializeComponent();
        }

        private void txtAlphanumericNumber_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnConvertToNumbericOnly_Click(object sender, EventArgs e)
        {
            string alpha =Convert.ToString(txtAlphanumericNumber.Text).ToLower();
            char[] chStr = new char[alpha.Length];
            for(int i=0; i<alpha.Length; i++)
            {
                if (char.IsDigit(alpha[i]) == false)
                {
                    
                    if (alpha[i]=='a' || alpha[i] =='b' || alpha[i] == 'c')
                    {
                        chStr[i] = '2';
                    }
                    else if (alpha[i] == 'd' || alpha[i] == 'e' || alpha[i] == 'f')
                    {
                        chStr[i] = '3';
                    }
                    else if (alpha[i] == 'g' || alpha[i] == 'h' || alpha[i] == 'i')
                    {
                        chStr[i] = '4';
                    }
                    else if (alpha[i] == 'j' || alpha[i] == 'k' || alpha[i] == 'l')
                    {
                        chStr[i] = '5';
                    }
                    else if (alpha[i] == 'm' || alpha[i] == 'n' || alpha[i] == 'o')
                    {
                        chStr[i] = '6';
                    }
                    else if (alpha[i] == 'p' || alpha[i] == 'q' || alpha[i] == 'r' || alpha[i] == 's')
                    {
                        chStr[i] = '7';
                    }
                    else if (alpha[i] == 't' || alpha[i] == 'u' || alpha[i] == 'v')
                    {
                        chStr[i] = '8';
                    }
                    else if (alpha[i] == 'w' || alpha[i] == 'x' || alpha[i] == 'y' || alpha[i] == 'z')
                    {
                        chStr[i] = '9';
                    }
                    else
                    {
                        chStr[i] = alpha[i];
                    }
                }
                else
                {
                    chStr[i] = alpha[i];
                }
            }
             string res = "";
            for(int i=0; i<alpha.Length; i++)
            {
                res += chStr[i].ToString();
            }
            txtNumbericOnly.Text = res.ToString();
            Console.WriteLine(chStr);
        }
    }
}
