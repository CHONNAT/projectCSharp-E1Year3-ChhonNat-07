﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace caculator_letter_grade
{
    public partial class frmCalculatorLetterGrade : Form
    {
        public frmCalculatorLetterGrade()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void frmCaculatorLetterGrade_Load(object sender, EventArgs e)
        {

        }

        private void btnCalculateLetterGrade_Click(object sender, EventArgs e)
        {
            
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
        }

        private void txtLetterGrade_TextChanged(object sender, EventArgs e)
        {

        }

        private void textNumbericGrade_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
