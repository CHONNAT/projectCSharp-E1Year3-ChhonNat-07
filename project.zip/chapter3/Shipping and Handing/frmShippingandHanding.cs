﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Shipping_and_Handing
{
    public partial class frmShippingandHanding : Form
    {
        public frmShippingandHanding()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void txtOrderTotal_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnCalculateGrandTotal_Click(object sender, EventArgs e)
        {
            decimal priceOrder = Convert.ToDecimal(txtOrderTotal.Text);
            string preferrered = Convert.ToString(txtCustomerType.Text);
            decimal t=.07m;
            decimal shippingFlee, Saletax, SaleTotal, p=0m;
            if (preferrered == "n" || preferrered == "N")
            {
                p = .1m;
            }
            if (preferrered == "p" || preferrered == "P")
            {
                p = 0m;
            }
            shippingFlee = priceOrder * p;
            Saletax = priceOrder * t;
            SaleTotal = priceOrder + (shippingFlee + Saletax);
            txtShipping.Text = shippingFlee.ToString("c");
            txtSalesTax.Text = Saletax.ToString("c");
            txtGrandTotal.Text = SaleTotal.ToString("c");
            txtGrandTotal.Focus();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void txtShipping_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtShipping_TextChanged_1(object sender, EventArgs e)
        {

        }
    }
}
