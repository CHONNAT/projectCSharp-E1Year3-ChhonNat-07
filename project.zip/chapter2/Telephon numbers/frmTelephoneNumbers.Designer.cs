﻿namespace Telephon_numbers
{
    partial class frmTelephoneNumbers
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtAlphanumericNumber = new System.Windows.Forms.TextBox();
            this.txtNumbericOnly = new System.Windows.Forms.TextBox();
            this.btnConvertToNumbericOnly = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.label1.Location = new System.Drawing.Point(26, 41);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(147, 19);
            this.label1.TabIndex = 0;
            this.label1.Text = "&Alphanumeric Number";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.label2.Location = new System.Drawing.Point(26, 79);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(101, 19);
            this.label2.TabIndex = 1;
            this.label2.Text = "Numberic Only";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtAlphanumericNumber
            // 
            this.txtAlphanumericNumber.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.txtAlphanumericNumber.Location = new System.Drawing.Point(174, 37);
            this.txtAlphanumericNumber.Margin = new System.Windows.Forms.Padding(2);
            this.txtAlphanumericNumber.Name = "txtAlphanumericNumber";
            this.txtAlphanumericNumber.Size = new System.Drawing.Size(298, 25);
            this.txtAlphanumericNumber.TabIndex = 1;
            this.txtAlphanumericNumber.TextChanged += new System.EventHandler(this.txtAlphanumericNumber_TextChanged);
            // 
            // txtNumbericOnly
            // 
            this.txtNumbericOnly.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.txtNumbericOnly.Location = new System.Drawing.Point(174, 74);
            this.txtNumbericOnly.Margin = new System.Windows.Forms.Padding(2);
            this.txtNumbericOnly.Name = "txtNumbericOnly";
            this.txtNumbericOnly.ReadOnly = true;
            this.txtNumbericOnly.Size = new System.Drawing.Size(298, 25);
            this.txtNumbericOnly.TabIndex = 3;
            this.txtNumbericOnly.TabStop = false;
            // 
            // btnConvertToNumbericOnly
            // 
            this.btnConvertToNumbericOnly.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.btnConvertToNumbericOnly.Location = new System.Drawing.Point(30, 134);
            this.btnConvertToNumbericOnly.Margin = new System.Windows.Forms.Padding(2);
            this.btnConvertToNumbericOnly.Name = "btnConvertToNumbericOnly";
            this.btnConvertToNumbericOnly.Size = new System.Drawing.Size(102, 66);
            this.btnConvertToNumbericOnly.TabIndex = 2;
            this.btnConvertToNumbericOnly.Text = "&Convert to Numberic Only";
            this.btnConvertToNumbericOnly.UseVisualStyleBackColor = true;
            this.btnConvertToNumbericOnly.Click += new System.EventHandler(this.btnConvertToNumbericOnly_Click);
            // 
            // btnExit
            // 
            this.btnExit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnExit.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.btnExit.Location = new System.Drawing.Point(370, 134);
            this.btnExit.Margin = new System.Windows.Forms.Padding(2);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(102, 66);
            this.btnExit.TabIndex = 3;
            this.btnExit.Text = "E&xit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // frmTelephoneNumbers
            // 
            this.AcceptButton = this.btnConvertToNumbericOnly;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.btnExit;
            this.ClientSize = new System.Drawing.Size(517, 243);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnConvertToNumbericOnly);
            this.Controls.Add(this.txtNumbericOnly);
            this.Controls.Add(this.txtAlphanumericNumber);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "frmTelephoneNumbers";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Telephone Numbers";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtAlphanumericNumber;
        private System.Windows.Forms.TextBox txtNumbericOnly;
        private System.Windows.Forms.Button btnConvertToNumbericOnly;
        private System.Windows.Forms.Button btnExit;
    }
}

