﻿namespace System
{
    internal class Windows
    {
    }
}