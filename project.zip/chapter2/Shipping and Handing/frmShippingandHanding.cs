﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Shipping_and_Handing
{
    public partial class frmShippingandHanding : Form
    {
        public frmShippingandHanding()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void txtOrderTotal_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnCalculateGrandTotal_Click(object sender, EventArgs e)
        {
            
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
        }

        private void txtShipping_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtShipping_TextChanged_1(object sender, EventArgs e)
        {

        }
    }
}
