﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace caculator_letter_grade
{
    public partial class frmCalculatorLetterGrade : Form
    {
        public frmCalculatorLetterGrade()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void frmCaculatorLetterGrade_Load(object sender, EventArgs e)
        {

        }
        char grade;
        private void btnCalculateLetterGrade_Click(object sender, EventArgs e)
        {
            try
            {
                decimal numgrade = Convert.ToDecimal(textNumbericGrade.Text);
                char grade;
                if (numgrade > 0 && numgrade <= 100)
                {
                    if (numgrade >= 90)
                        grade = 'A';
                    else if (numgrade >= 80)
                        grade = 'B';
                    else if (numgrade >= 70)
                        grade = 'C';
                    else if (numgrade >= 60)
                        grade = 'D';
                    else if (numgrade >= 50)
                        grade = 'E';
                    else
                        grade = 'F';
                }
                else
                {
                    MessageBox.Show("You must input 1-100");
                }
                txtLetterGrade.Text = grade.ToString();
                textNumbericGrade.Focus();
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void txtLetterGrade_TextChanged(object sender, EventArgs e)
        {

        }

        private void textNumbericGrade_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
