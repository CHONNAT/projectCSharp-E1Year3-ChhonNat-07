﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Student_Population
{
    public partial class frmStudentPopulation : Form
    {
        public frmStudentPopulation()
        {
            InitializeComponent();
        }

        private void frmStudentPopulation_Load(object sender, EventArgs e)
        {

        }

        private void btnExit_Click(object sender, EventArgs e)
        {
        }

        private void btnProjectStudentPopulation_Click(object sender, EventArgs e)
        {

        }

        private void txtAnnualGrowthRate_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
