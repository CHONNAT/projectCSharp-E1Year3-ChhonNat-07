﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Student_Population
{
    public partial class frmStudentPopulation : Form
    {
        public frmStudentPopulation()
        {
            InitializeComponent();
        }

        private void frmStudentPopulation_Load(object sender, EventArgs e)
        {

        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnProjectStudentPopulation_Click(object sender, EventArgs e)
        {
            decimal numOfStu = Convert.ToDecimal(txtNumberOfStudentsToday.Text);
            decimal AGR = Convert.ToDecimal(txtAnnualGrowthRate.Text);
            int NumYear = Convert.ToInt32(txtNumberOfYears.Text);
            double RES = 0;
            double D = (double)(1 + AGR / 100);


            //*************< for loop >****************
           /* 
            for(int i=1; i<=NumYear; i++)
            {
               RES = ((double)numOfStu * Math.Pow(D, i));
            }*/
            


            //*************< while loop >****************
            int i = 1;
            while (i <= NumYear)
            {
               RES = ((double)numOfStu * Math.Pow(D, i));
                i++;
            }

            txtAnnualGrowthRate.Text = AGR.ToString(AGR+"%");
            txtProjectedNumberOfStudents.Text = RES.ToString("N0");
            txtProjectedNumberOfStudents.Focus();

        }

        private void txtAnnualGrowthRate_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
